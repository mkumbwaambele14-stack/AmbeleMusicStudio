# Ambele Music Studio

A starter Android music studio app inspired by the layout and workflow of mobile music-making apps.

Current starter features:
- Ambele Music Studio branding
- Piano, Guitar, Bass, Drums sections
- Simple playable piano buttons using Android ToneGenerator
- Record / Play / Stop UI

Next development:
- Real sampled piano/guitar/bass/drum sounds
- Multi-track recording
- Mixer
- Save projects
- MIDI support
- Export audio
