package com.ambele.musicstudio

import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.widget.Button
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity

class MainActivity : android.app.Activity() {
    private var tone: ToneGenerator? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tone = ToneGenerator(AudioManager.STREAM_MUSIC, 90)

        val bg = Color.rgb(9, 11, 18)
        val white = Color.WHITE
        val purple = Color.rgb(124, 77, 255)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 20)
            setBackgroundColor(bg)
        }

        val title = TextView(this).apply {
            text = "Ambele Music Studio"
            textSize = 25f
            setTextColor(white)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        root.addView(title)

        val sub = TextView(this).apply {
            text = "🎶 Cheza • Rekodi • Tengeneza"
            textSize = 15f
            setTextColor(Color.LTGRAY)
            setPadding(0, 8, 0, 20)
        }
        root.addView(sub)

        val instruments = arrayOf("🎹 Piano", "🎸 Guitar", "🎸 Bass", "🥁 Drums")
        val grid = GridLayout(this).apply {
            columnCount = 2
            rowCount = 2
        }

        instruments.forEachIndexed { index, name ->
            val b = Button(this).apply {
                text = name
                textSize = 17f
                setTextColor(white)
                setBackgroundColor(Color.rgb(28, 31, 43))
                setOnClickListener {
                    if (index == 0) playNote()
                }
            }
            val p = GridLayout.LayoutParams().apply {
                width = 0
                height = 150
                columnSpec = GridLayout.spec(index % 2, 1f)
                rowSpec = GridLayout.spec(index / 2)
                setMargins(8, 8, 8, 8)
            }
            grid.addView(b, p)
        }
        root.addView(grid)

        val pianoTitle = TextView(this).apply {
            text = "Piano — gusa funguo kucheza"
            textSize = 16f
            setTextColor(white)
            gravity = Gravity.CENTER
            setPadding(0, 22, 0, 10)
        }
        root.addView(pianoTitle)

        val keys = GridLayout(this).apply {
            columnCount = 8
        }
        for (i in 0 until 8) {
            val key = Button(this).apply {
                text = (i + 1).toString()
                textSize = 18f
                setOnClickListener { playNote() }
            }
            keys.addView(key, GridLayout.LayoutParams().apply {
                width = 0
                height = 130
                columnSpec = GridLayout.spec(i, 1f)
                setMargins(2, 2, 2, 2)
            })
        }
        root.addView(keys)

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 0)
        }
        arrayOf("🔴 Rekodi", "▶ Play", "⏹ Stop").forEach { label ->
            val b = Button(this).apply {
                text = label
                setTextColor(white)
                setBackgroundColor(purple)
            }
            controls.addView(b, LinearLayout.LayoutParams(0, 60, 1f).apply {
                setMargins(4, 0, 4, 0)
            })
        }
        root.addView(controls)

        setContentView(root)
    }

    private fun playNote() {
        tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 120)
    }

    override fun onDestroy() {
        tone?.release()
        super.onDestroy()
    }
}
