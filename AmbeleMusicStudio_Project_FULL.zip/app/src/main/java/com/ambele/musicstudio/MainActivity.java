package com.ambele.musicstudio;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.media.*;
import android.view.*;
import android.widget.*;
import java.io.File;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    TextView status;
    MediaRecorder recorder;
    File recordingFile;
    PianoView piano;

    int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 10);
        showHome();
    }

    TextView tv(String s, float size) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(size);
        t.setGravity(Gravity.CENTER); t.setPadding(dp(10),dp(8),dp(10),dp(8)); return t;
    }
    Button btn(String s) {
        Button b = new Button(this); b.setText(s); b.setTextSize(15); b.setTextColor(Color.WHITE);
        GradientDrawable g = new GradientDrawable(); g.setColor(Color.rgb(35,35,42)); g.setCornerRadius(dp(14)); b.setBackground(g);
        return b;
    }

    void base(String title) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(12,12,16));
        TextView head = tv(title, 23); head.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        head.setPadding(dp(18),dp(20),dp(18),dp(14)); root.addView(head,new LinearLayout.LayoutParams(-1,dp(70)));
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(14),dp(8),dp(14),dp(8));
        root.addView(content,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav = new LinearLayout(this); nav.setPadding(dp(8),dp(5),dp(8),dp(8));
        String[] names={"Cheza","Rekodi","Tengeneza"};
        for(String n:names){ Button x=btn(n); nav.addView(x,new LinearLayout.LayoutParams(0,dp(58),1));
            if(n.equals("Cheza")) x.setOnClickListener(v->showPlay());
            if(n.equals("Rekodi")) x.setOnClickListener(v->showRecord());
            if(n.equals("Tengeneza")) x.setOnClickListener(v->showCreate());
        }
        root.addView(nav,new LinearLayout.LayoutParams(-1,dp(70)));
        setContentView(root);
    }

    void showHome(){ showPlay(); }

    void showPlay(){
        base("Ambele Music Studio");
        TextView s=tv("🎹 Cheza — Piano",18); content.addView(s,new LinearLayout.LayoutParams(-1,dp(48)));
        status=tv("Gusa funguo kucheza sauti",14); content.addView(status,new LinearLayout.LayoutParams(-1,dp(45)));
        piano=new PianoView(); content.addView(piano,new LinearLayout.LayoutParams(-1,0,1));
        Button stop=btn("⏹  STOP"); content.addView(stop,new LinearLayout.LayoutParams(-1,dp(55))); stop.setOnClickListener(v->piano.stop());
    }

    void showRecord(){
        base("Rekodi");
        TextView info=tv("Rekodi sauti yako",20); content.addView(info,new LinearLayout.LayoutParams(-1,dp(60)));
        status=tv("Tayari kurekodi",15); content.addView(status,new LinearLayout.LayoutParams(-1,dp(55)));
        Button rec=btn("🔴  ANZA KUREKODI"); content.addView(rec,new LinearLayout.LayoutParams(-1,dp(65)));
        Button stop=btn("⏹  SIMAMISHA"); content.addView(stop,new LinearLayout.LayoutParams(-1,dp(65)));
        Button play=btn("▶  CHEZA REKODI"); content.addView(play,new LinearLayout.LayoutParams(-1,dp(65)));
        rec.setOnClickListener(v->startRecording()); stop.setOnClickListener(v->stopRecording()); play.setOnClickListener(v->playRecording());
    }

    void showCreate(){
        base("Tengeneza");
        TextView a=tv("🎵 Tengeneza Beat",22); content.addView(a,new LinearLayout.LayoutParams(-1,dp(65)));
        TextView hint=tv("Chagua pad kuanza beat yako",15); content.addView(hint,new LinearLayout.LayoutParams(-1,dp(55)));
        LinearLayout grid=new LinearLayout(this); grid.setOrientation(LinearLayout.VERTICAL);
        String[] pads={"KICK","SNARE","HI-HAT","CLAP","BASS","TOM"};
        for(int r=0;r<3;r++){ LinearLayout row=new LinearLayout(this);
            for(int c=0;c<2;c++){ String p=pads[r*2+c]; Button q=btn("🥁 "+p); row.addView(q,new LinearLayout.LayoutParams(0,dp(75),1)); q.setOnClickListener(v->tone(220 + p.hashCode()%300)); }
            grid.addView(row,new LinearLayout.LayoutParams(-1,dp(82))); }
        content.addView(grid);
    }

    void tone(double freq){
        final int sr=44100, n=(int)(sr*.18); short[] data=new short[n];
        for(int i=0;i<n;i++){ double env=1.0-i/(double)n; data[i]=(short)(Math.sin(2*Math.PI*freq*i/sr)*12000*env); }
        AudioTrack at=new AudioTrack(AudioManager.STREAM_MUSIC,sr,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_16BIT,n*2,AudioTrack.MODE_STATIC);
        at.write(data,0,n); at.play(); at.setNotificationMarkerPosition(n); at.setPlaybackPositionUpdateListener(new AudioTrack.OnPlaybackPositionUpdateListener(){public void onMarkerReached(AudioTrack t){t.release();} public void onPeriodicNotification(AudioTrack t){}}); 
    }

    void startRecording(){
        try{
            if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},10); return;}
            recordingFile=new File(getExternalFilesDir(null),"ambele_recording.m4a");
            recorder=new MediaRecorder(); recorder.setAudioSource(MediaRecorder.AudioSource.MIC); recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC); recorder.setOutputFile(recordingFile.getAbsolutePath()); recorder.prepare(); recorder.start();
            status.setText("🔴 Inarekodi...");
        }catch(Exception e){ if(status!=null) status.setText("Imeshindikana kuanza rekodi"); }
    }
    void stopRecording(){ try{ if(recorder!=null){recorder.stop(); recorder.release(); recorder=null; status.setText("✅ Rekodi imehifadhiwa");}}catch(Exception e){} }
    void playRecording(){
        try{
            if(recordingFile==null || !recordingFile.exists()){status.setText("Hakuna rekodi bado"); return;}
            MediaPlayer mp=new MediaPlayer(); mp.setDataSource(recordingFile.getAbsolutePath()); mp.prepare(); mp.start();
            mp.setOnCompletionListener(x->x.release()); status.setText("▶ Inacheza rekodi...");
        }catch(Exception e){status.setText("Imeshindikana kucheza rekodi");}
    }

    class PianoView extends View {
        Paint p=new Paint(1); int[] freqs={262,294,330,349,392,440,494,523};
        boolean down=false; AudioTrack current;
        PianoView(){super(MainActivity.this); p.setTypeface(Typeface.DEFAULT_BOLD); setBackgroundColor(Color.rgb(18,18,22));}
        protected void onDraw(Canvas c){super.onDraw(c); float w=getWidth()/8f,h=getHeight();
            p.setColor(Color.WHITE); for(int i=0;i<8;i++){c.drawRect(i*w+2,5,(i+1)*w-2,h-5,p); p.setColor(Color.DKGRAY);p.setTextSize(dp(15));c.drawText("CDEFGABC".substring(i,i+1),(i+.5f)*w-5,h-20,p);p.setColor(Color.WHITE);}
        }
        public boolean onTouchEvent(android.view.MotionEvent e){if(e.getAction()==ACTION_DOWN||e.getAction()==ACTION_MOVE){int i=(int)(e.getX()/(getWidth()/8f)); if(i>=0&&i<8){tone(freqs[i]); if(status!=null)status.setText("♪ Note "+(i+1));} return true;} return true;}
        void stop(){}
    }
}
